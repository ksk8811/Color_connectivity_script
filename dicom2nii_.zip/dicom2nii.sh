#!/bin/bash
path=`dirname $0`
sleep 1
cd $path
echo "This Script uses dcm2nii command to convert multiple DICOM format data to various format such as
     	                  Compressed 4D NIfTI nii.gz 
			  4D NIfTI nii 
     			  3D NIfTI hdr/img 
			  3D Anlyze hdr/img

         dcm2nii was written by Dr. Chris Rorden 
              http://www.cabiatl.com/mricro/

"
echo "By Jamaan Alghamdi & Dr. Vanessa Sluming"
echo "University of Liverpool"
echo "jamaan.alghamdi@gmail.com"
echo "http://www.easyneuroimaging.com"
echo "18-02-2012

"
echo "###### If mricron directory is not **** /Applications/mricronmac ****"
echo " Please do not forget to change it using any text editor ######


"
echo "Write down conversion type 
## select one of the following options ##
 	   		  nii.gz
			  nii
 		          NIfTI_img
                          Anlyze_img
"
read conversion_type


if [ "$conversion_type" = nii.gz ]; then

###### Change directories in the following 2 lines to your micron directory ######
cd /Applications/mricronmac
export PATH=/Applications/mricronmac
for i in "$path"/*/; 
do dcm2nii -a n -d n -e n -i n -p n -g y -o $path/ $i;
done



elif [ "$conversion_type" = nii ]; then

###### Change directories in the following 2 lines to your micron directory ######
cd /Applications/mricronmac
export PATH=/Applications/mricronmac
for i in "$path"/*/;
do dcm2nii -a n -d n -e n -i n -p n -g n -o $path/ $i; done



elif [ "$conversion_type" = NIfTI_img ]; then

###### Change directories in the following 2 lines to your micron directory ######
cd /Applications/mricronmac
export PATH=/Applications/mricronmac
for i in "$path"/*/;
do dcm2nii -a n -d n -e n -i n -p n -g n -n n -o $path/ $i; done



elif [ "$conversion_type" = Anlyze_img ]; then

###### Change directories in the following 2 lines to your micron directory ######
cd /Applications/mricronmac
export PATH=/Applications/mricronmac
for i in "$path"/*/;
do dcm2nii -a n -d n -e n -i n -p n -g n -n n -s y -o $path/ $i; done

fi

