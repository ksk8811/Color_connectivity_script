
plots = struct();
plots.maps = {[1,2,3,4]};
plots.gradients = {{ ...
    colorGradient([0 0 0]/255, [0 159 227]/255, 128), ...
    colorGradient([0 0 0]/255, [0 150 64]/255, 128), ...
    colorGradient([0 0 0]/255, [227 6 19]/255, 128), ... 
    colorGradient([0 0 0]/255, [235 178 4]/255, 128),...
    } ...
};

curr_maps = {};  % Call array with threshholded .nii files.
% for res=plots.maps{plt}
%     curr_maps{end+1} = [plot_base_dirname plot_base(res).name '/final_map.nii'];
% end

global SAMI_conn_no_colorbar;
SAMI_conn_no_colorbar = false;


global SAMI_conn_colorgradiants;
SAMI_conn_colorgradiants = plots.gradients{1};

conn_mesh_display_multi(curr_maps,'');